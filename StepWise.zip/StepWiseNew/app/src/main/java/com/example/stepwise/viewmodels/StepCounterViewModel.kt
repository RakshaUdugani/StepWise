package com.example.stepwise.viewmodels

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.stepwise.data.StepGoalPreferences
import com.example.stepwise.googlefit.GoogleFitManager
import kotlinx.coroutines.launch

class StepCounterViewModel(application: Application) : AndroidViewModel(application) {

    private val fit = GoogleFitManager(application)
    private val goalPrefs = StepGoalPreferences(application)

    val todaySteps = MutableLiveData(0)
    val weeklySteps = MutableLiveData<List<Int>>(List(7) { 0 })

    val dailyGoal = goalPrefs.goal

    fun saveDailyGoal(goal: Int) {
        goalPrefs.saveGoal(goal)
    }

    fun clearGoal() {
        goalPrefs.clearGoal()
    }

    fun isSignedIn() = fit.isSignedIn()

    fun requestPermissions(activity: Activity, reqCode: Int) {
        fit.requestPermissions(activity, reqCode)
    }

    fun startRealTime() {

        // Required for steps to work
        fit.subscribeToSteps()

        todaySteps.value = 0

        fit.startRealTimeListener { delta ->
            val current = todaySteps.value ?: 0
            todaySteps.postValue(current + delta)
        }
    }

    fun loadWeekly() {
        viewModelScope.launch {
            fit.readWeeklySteps { result ->
                val finalList = if (result.isEmpty()) List(7) { 0 } else result
                weeklySteps.postValue(finalList)
            }
        }
    }
}
