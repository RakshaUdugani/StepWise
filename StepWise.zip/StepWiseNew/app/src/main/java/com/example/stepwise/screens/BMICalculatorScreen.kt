package com.example.stepwise.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import com.example.stepwise.data.UserPreferences

// --------------------- VIEWMODEL -------------------------
class BMIViewModel(private val context: Context) : ViewModel() {

    private val prefs = UserPreferences(context)

    val savedBMI = prefs.bmi

    fun saveBMI(value: Float) {
        prefs.saveBMI(value)
    }
}

// ---------------- BMI INTERPRETATION ---------------------
fun interpretBMI(bmi: Float): String {
    return when {
        bmi < 18.5f -> "Underweight"
        bmi < 25f -> "Normal Weight"
        bmi < 30f -> "Pre-Obesity"
        bmi < 35f -> "Obesity Class I"
        bmi < 40f -> "Obesity Class II"
        else -> "Obesity Class III"
    }
}

// ------------------ SCREEN UI ----------------------------
@Composable
fun BMICalculatorScreen(viewModel: BMIViewModel) {

    var height by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }

    val savedBMI by viewModel.savedBMI.collectAsState()

    val gradient = Brush.verticalGradient(
        listOf(Color(0xFFFFF1EB), Color(0xFFFEE1F3))
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text("BMI Calculator", fontSize = 28.sp, color = Color(0xFF7A00B3))

        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = height,
            onValueChange = { height = it },
            label = { Text("Height (cm)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = weight,
            onValueChange = { weight = it },
            label = { Text("Weight (kg)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                val h = height.toFloatOrNull()
                val w = weight.toFloatOrNull()
                if (h != null && w != null && h > 0f) {
                    val bmi = w / ((h / 100) * (h / 100))
                    viewModel.saveBMI(bmi)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB36CFF))
        ) {
            Text("Calculate", color = Color.White)
        }

        // ---------------------------------------------------------
        // ⭐ SHOW BMI ONLY IF USER HAS PREVIOUSLY CALCULATED IT
        // ---------------------------------------------------------
        if (savedBMI > 0f) {

            Spacer(Modifier.height(30.dp))

            Text(
                text = "Saved BMI: ${String.format("%.2f", savedBMI)}",
                fontSize = 22.sp,
                color = Color(0xFF5A007A)
            )

            Spacer(Modifier.height(10.dp))

            val bmiCategory = interpretBMI(savedBMI)

            Text(
                text = "Category: $bmiCategory",
                fontSize = 20.sp,
                color = Color(0xFF7A00B3)
            )
        }
    }
}
