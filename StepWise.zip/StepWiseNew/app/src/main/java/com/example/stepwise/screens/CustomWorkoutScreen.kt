package com.example.stepwise.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.stepwise.data.CustomWorkoutPreferences
import com.example.stepwise.ui.theme.CardPurple
import com.example.stepwise.ui.theme.PurpleDark
import com.example.stepwise.ui.theme.TextPurple

data class WorkoutEntry(
    val name: String,
    val duration: Int,   // in minutes
    val calories: Int    // kcal
)

@Composable
fun CustomWorkoutScreen() {

    val context = LocalContext.current
    val prefs = remember { CustomWorkoutPreferences(context) }

    var workoutList by remember { mutableStateOf(prefs.loadWorkouts()) }

    var name by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("") }

    val gradient = Brush.verticalGradient(
        listOf(Color(0xFFF3E5F5), Color(0xFFE8D5F5))
    )

    // 🔥 Correct kcal formula (NO ×1000)
    fun calculateCalories(name: String, duration: Int): Int {

        val weight = 60f  // assumed weight

        val met = when (name.lowercase()) {
            "walking" -> 3.5f
            "running" -> 9.5f
            "cycling" -> 7.5f
            "yoga" -> 3.0f
            "strength", "strength training" -> 6.0f
            "hiit" -> 8.0f
            "dance" -> 5.0f
            "aerobics" -> 6.5f
            else -> 5.0f   // default MET
        }

        val hours = duration / 60f
        val kcal = met * weight * hours   // kcal, correct fitness unit

        return kcal.toInt()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(20.dp)
    ) {

        Text("Add Workout", fontSize = 22.sp, color = TextPurple)

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Workout Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = duration,
            onValueChange = { duration = it.filter { ch -> ch.isDigit() } },
            label = { Text("Duration (minutes)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))

        // ADD button
        Button(
            onClick = {
                val d = duration.toIntOrNull()
                if (name.isNotBlank() && d != null) {

                    val caloriesCalculated = calculateCalories(name, d)

                    workoutList = workoutList + WorkoutEntry(
                        name = name,
                        duration = d,
                        calories = caloriesCalculated
                    )

                    prefs.saveWorkouts(workoutList)

                    name = ""
                    duration = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add Workout")
        }

        Spacer(Modifier.height(20.dp))

        Text("Your Workouts", fontSize = 20.sp, color = TextPurple)

        Spacer(Modifier.height(10.dp))

        LazyColumn {
            items(workoutList.indices.toList()) { index ->

                val workout = workoutList[index]

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    elevation = CardDefaults.cardElevation(6.dp),
                    colors = CardDefaults.cardColors(containerColor = CardPurple)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(18.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Column(modifier = Modifier.weight(1f)) {

                            Text(workout.name, fontSize = 22.sp, color = TextPurple)

                            Spacer(Modifier.height(8.dp))

                            Text(
                                text = "Duration: ${workout.duration} min",
                                fontSize = 16.sp,
                                color = PurpleDark
                            )

                            Spacer(Modifier.height(4.dp))

                            // Correct kcal display
                            Text(
                                text = "Calories: ${workout.calories} kcal",
                                fontSize = 16.sp,
                                color = PurpleDark
                            )
                        }

                        // DELETE BUTTON
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFD9C2EB))
                                .clickable {
                                    prefs.deleteWorkout(index)
                                    workoutList = prefs.loadWorkouts()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
