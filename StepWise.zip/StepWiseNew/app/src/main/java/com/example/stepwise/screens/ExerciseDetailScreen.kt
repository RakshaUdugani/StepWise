package com.example.stepwise.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Workout model
data class WorkoutDetail(
    val name: String,
    val duration: String,
    val calories: String
)

@Composable
fun ExerciseDetailScreen(category: String) {

    val gradient = Brush.verticalGradient(
        listOf(
            Color(0xFFF3E5F5),
            Color(0xFFE8D9F6)
        )
    )

    val workouts = when (category) {

        "Abs workout" -> listOf(
            WorkoutDetail("Crunches", "3 × 15", "40 kcal"),
            WorkoutDetail("Leg Raises", "3 × 12", "45 kcal"),
            WorkoutDetail("Plank", "3 × 30 sec", "25 kcal"),
            WorkoutDetail("Bicycle Crunch", "3 × 20", "35 kcal"),
            WorkoutDetail("Mountain Climbers", "3 × 20", "50 kcal"),
            WorkoutDetail("Heel Touches", "3 × 20", "30 kcal"),
            WorkoutDetail("Toe Touches", "3 × 15", "35 kcal"),
            WorkoutDetail("Russian Twists", "3 × 20", "40 kcal"),
            WorkoutDetail("Flutter Kicks", "3 × 20", "30 kcal"),
            WorkoutDetail("V-Ups", "3 × 12", "40 kcal")
        )

        "Leg workout" -> listOf(
            WorkoutDetail("Squats", "3 × 15", "50 kcal"),
            WorkoutDetail("Lunges", "3 × 12", "40 kcal"),
            WorkoutDetail("Glute Bridges", "3 × 15", "35 kcal"),
            WorkoutDetail("Calf Raises", "3 × 20", "25 kcal"),
            WorkoutDetail("Wall Sit", "3 × 30 sec", "30 kcal"),
            WorkoutDetail("Jump Squats", "3 × 10", "45 kcal"),
            WorkoutDetail("Donkey Kicks", "3 × 15", "30 kcal"),
            WorkoutDetail("Side Lunges", "3 × 12", "35 kcal"),
            WorkoutDetail("Hamstring Curls", "3 × 12", "30 kcal"),
            WorkoutDetail("Bulgarian Split Squat", "3 × 10", "45 kcal")
        )

        "Arm workout" -> listOf(
            WorkoutDetail("Push-ups", "3 × 12", "45 kcal"),
            WorkoutDetail("Tricep Dips", "3 × 12", "40 kcal"),
            WorkoutDetail("Bicep Curls", "3 × 15", "35 kcal"),
            WorkoutDetail("Hammer Curls", "3 × 12", "30 kcal"),
            WorkoutDetail("Diamond Push-ups", "3 × 8", "40 kcal"),
            WorkoutDetail("Shoulder Taps", "3 × 15", "25 kcal"),
            WorkoutDetail("Plank Up-Downs", "3 × 12", "40 kcal"),
            WorkoutDetail("Resistance Band Pulls", "3 × 15", "30 kcal"),
            WorkoutDetail("Arm Circles", "3 × 30 sec", "20 kcal"),
            WorkoutDetail("Incline Push-ups", "3 × 12", "35 kcal")
        )

        "Chest workout" -> listOf(
            WorkoutDetail("Wide Push-ups", "3 × 12", "40 kcal"),
            WorkoutDetail("Incline Push-ups", "3 × 12", "35 kcal"),
            WorkoutDetail("Bench Press", "3 × 10", "60 kcal"),
            WorkoutDetail("Chest Fly", "3 × 12", "45 kcal"),
            WorkoutDetail("Decline Push-ups", "3 × 10", "40 kcal"),
            WorkoutDetail("Dumbbell Press", "3 × 12", "55 kcal"),
            WorkoutDetail("Cable Crossovers", "3 × 15", "45 kcal"),
            WorkoutDetail("Clap Push-ups", "3 × 8", "50 kcal"),
            WorkoutDetail("Pec Deck", "3 × 12", "40 kcal"),
            WorkoutDetail("Chest Dips", "3 × 10", "50 kcal")
        )

        "Back workout" -> listOf(
            WorkoutDetail("Superman", "3 × 15 sec", "25 kcal"),
            WorkoutDetail("Bent-over Rows", "3 × 12", "45 kcal"),
            WorkoutDetail("Reverse Fly", "3 × 12", "40 kcal"),
            WorkoutDetail("Deadlift", "3 × 10", "60 kcal"),
            WorkoutDetail("Cat-Cow", "3 × 10", "20 kcal"),
            WorkoutDetail("Back Extensions", "3 × 10", "35 kcal"),
            WorkoutDetail("Lat Pull-down", "3 × 12", "45 kcal"),
            WorkoutDetail("Good Mornings", "3 × 12", "35 kcal"),
            WorkoutDetail("T-Bar Row", "3 × 10", "50 kcal"),
            WorkoutDetail("Hyperextensions", "3 × 12", "40 kcal")
        )

        "Full-body workout" -> listOf(
            WorkoutDetail("Burpees", "3 × 10", "60 kcal"),
            WorkoutDetail("Jumping Jacks", "3 × 30 sec", "30 kcal"),
            WorkoutDetail("High Knees", "3 × 30 sec", "35 kcal"),
            WorkoutDetail("Plank Jumps", "3 × 15", "40 kcal"),
            WorkoutDetail("Squat to Press", "3 × 12", "50 kcal"),
            WorkoutDetail("Skater Jumps", "3 × 20", "40 kcal"),
            WorkoutDetail("Mountain Climbers", "3 × 20", "45 kcal"),
            WorkoutDetail("Bear Crawl", "3 × 20 sec", "35 kcal"),
            WorkoutDetail("Lateral Hops", "3 × 20", "30 kcal"),
            WorkoutDetail("Shadow Boxing", "3 × 1 min", "55 kcal")
        )

        else -> emptyList()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(20.dp)
    ) {

        Text(
            text = category,
            fontSize = 26.sp,
            color = Color(0xFF4A148C),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn {
            items(workouts) { workout ->
                Card(
                    colors = CardDefaults.cardColors(Color(0xFFEDE7F6)),
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(workout.name, fontSize = 20.sp, color = Color(0xFF6A1B9A))
                        Spacer(Modifier.height(6.dp))
                        Text("Duration: ${workout.duration}", style = MaterialTheme.typography.bodyMedium)
                        Text("Calories: ${workout.calories}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
