package com.example.stepwise.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

data class ExerciseCategory(
    val name: String,
    val workouts: List<String>
)

@Composable
fun ExerciseListScreen(navController: NavController) {

    val categories = listOf(
        ExerciseCategory(
            "Abs workout",
            listOf("Crunches", "Plank", "Leg raises", "Bicycle crunch", "Mountain climbers")
        ),
        ExerciseCategory(
            "Leg workout",
            listOf("Squats", "Lunges", "Glute bridges", "Calf raises", "Wall sit")
        ),
        ExerciseCategory(
            "Arm workout",
            listOf("Push-ups", "Tricep dips", "Bicep curls", "Hammer curls", "Diamond push-ups")
        ),
        ExerciseCategory(
            "Chest workout",
            listOf("Incline push-ups", "Dumbbell fly", "Bench press", "Wide push-ups", "Chest dips")
        ),
        ExerciseCategory(
            "Back workout",
            listOf("Superman", "Rows", "Reverse fly", "Deadlift", "Cat-cow")
        ),
        ExerciseCategory(
            "Full-body workout",
            listOf("Burpees", "Jumping jacks", "High knees", "Plank jacks", "Squat press")
        )
    )

    val gradient = Brush.verticalGradient(
        listOf(
            Color(0xFFF3E5F5),
            Color(0xFFE8D9F6)
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(20.dp)
    ) {

        Text(
            "Exercise Packs",
            fontSize = 24.sp,
            color = Color(0xFF4A148C)
        )

        Spacer(Modifier.height(12.dp))

        LazyColumn {
            items(categories) { category ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clickable {
                            navController.navigate("exerciseDetail/${category.name}")
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFEDE7F6)
                    )
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            category.name,
                            fontSize = 20.sp,
                            color = Color(0xFF6A1B9A)
                        )
                    }
                }
            }
        }
    }
}
