package com.example.stepwise.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import android.content.Intent

data class Article(
    val title: String,
    val content: String,
    val link: String
)

@Composable
fun ArticlesScreen() {

    val context = LocalContext.current

    val articles = listOf(
        Article(
            "Beginner’s Guide to Healthy Eating",
            "A simple breakdown of balanced meals, portion control, and daily habits that improve digestion and energy.",
            "https://www.healthline.com/nutrition/healthy-eating-for-beginners"
        ),
        Article(
            "Healthy Snack Ideas",
            "Easy and nutritious snacks like yogurt, nuts, smoothies, fruits and oats for busy days.",
            "https://www.healthline.com/nutrition/29-healthy-snacks-for-weight-loss"
        ),

        Article(
            "Health Benefits of Walking",
            "Walking improves heart health, mental health, weight control, and overall well-being.",
            "https://en.wikipedia.org/wiki/Walking#Health_benefits"
        ),

                Article(
            "The Science Behind Weight Loss",
            "A simple explanation of calorie deficit, metabolism, and how your body burns fat over time.",
            "https://www.healthline.com/nutrition/how-to-lose-weight-as-fast-as-possible"
        ),
        Article(
            "Full-Body Exercise Guide",
            "List of strength, cardio and functional exercises that target the entire body.",
            "https://en.wikipedia.org/wiki/Physical_fitness"
        ),
        Article(
            "Why Sleep Matters for Fitness",
            "Sleep helps muscle recovery, stabilizes hormones, boosts metabolism and improves performance.",
            "https://www.sleepfoundation.org/sleep-hygiene"
        ),
        Article(
            "Healthy Foods That Support Immunity",
            "Fruits, vegetables, herbs and minerals that naturally improve immune function.",
            "https://en.wikipedia.org/wiki/Immune_system#Diet_and_nutrition"
        ),
        Article(
            "Strength Training for Beginners",
            "Basics of proper form, how to structure sets/reps and simple guidance to safely begin strength workouts.",
            "https://www.nerdfitness.com/blog/strength-training-101/"
        ),
        Article(
            "How Much Water Should You Drink Daily?",
            "A simple breakdown of daily hydration needs and tips to stay hydrated.",
            "https://en.wikipedia.org/wiki/Drinking_water"
        ),
        Article(
            "Beginner Workout Routine (Step-by-Step Guide)",
            "A simple, beginner-friendly guide to start exercising safely and build a long-term routine.",
            "https://www.wikihow.com/Start-Working-Out"
        )
    )

    val gradient = Brush.verticalGradient(
        listOf(Color(0xFFF3E5F5), Color(0xFFE8D9F6))
    )

    var expandedTitle by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(16.dp)
    ) {

        Text(
            text = "Health & Fitness Articles",
            fontSize = 24.sp,
            color = Color(0xFF4A148C),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn {

            items(articles) { article ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clickable {
                            expandedTitle =
                                if (expandedTitle == article.title) null else article.title
                        }
                        .animateContentSize(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE7F6)),
                    elevation = CardDefaults.cardElevation(4.dp)
                ) {

                    Column(modifier = Modifier.padding(16.dp)) {

                        // Title Always Visible
                        Text(
                            text = article.title,
                            fontSize = 20.sp,
                            color = Color(0xFF6A1B9A),
                            style = MaterialTheme.typography.titleMedium
                        )

                        // Content visible only when expanded
                        if (expandedTitle == article.title) {
                            Spacer(Modifier.height(8.dp))

                            Text(
                                text = article.content,
                                style = MaterialTheme.typography.bodyMedium
                            )

                            Spacer(Modifier.height(8.dp))

                            Text(
                                text = "Read more →",
                                color = Color(0xFF4A148C),
                                modifier = Modifier.clickable {

                                    val uri = article.link.toUri()

                                    // Try Chrome → fallback to system browser
                                    val chromeIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                                        setPackage("com.android.chrome")
                                    }

                                    try {
                                        context.startActivity(chromeIntent)
                                    } catch (e: Exception) {
                                        context.startActivity(
                                            Intent(Intent.ACTION_VIEW, uri)
                                        )
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
