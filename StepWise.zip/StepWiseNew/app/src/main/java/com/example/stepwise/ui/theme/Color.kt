package com.example.stepwise.ui.theme

import androidx.compose.ui.graphics.Color

// Pastel Lavender Palette
val PurpleLight = Color(0xFFF3E5F5)
val PurpleMedium = Color(0xFFE1BEE7)
val PurpleDark = Color(0xFF6A1B9A)

val TextPurple = Color(0xFF4A148C)
val CardPurple = Color(0xFFEDE7F6)
