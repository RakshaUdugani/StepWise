package com.example.stepwise.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.stepwise.data.UserPreferences
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.ui.text.font.FontWeight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {

    val prefs = remember { UserPreferences(navController.context) }
    var menuExpanded by remember { mutableStateOf(false) }

    val gradient = Brush.verticalGradient(
        listOf(Color(0xFFF3E5F5), Color(0xFFE1BEE7))
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("StepWise", color = Color(0xFF4A148C)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                ),
                actions = {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Menu",
                            tint = Color(0xFF4A148C)
                        )
                    }

                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Logout") },
                            onClick = {
                                menuExpanded = false
                                prefs.logout()
                                navController.navigate("login") {
                                    popUpTo("home") { inclusive = true }
                                }
                            }
                        )
                    }
                }
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(gradient)
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,   // center vertically
            horizontalAlignment = Alignment.CenterHorizontally // center horizontally
        ) {

            // ---- MAIN TITLE ----
            Text(
                text = "Welcome to StepWise!",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF6A1B9A)
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = "Your fitness journey begins here!",
                fontSize = 18.sp,
                color = Color(0xFF8E24AA)
            )

            Spacer(Modifier.height(40.dp))

            // ---- BMI BUTTON ----
            Button(
                onClick = { navController.navigate("bmi") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD1B3FF))
            ) {
                Text("BMI Calculator", color = Color.White, fontSize = 18.sp)
            }

            Spacer(Modifier.height(16.dp))

            // ---- WORKOUT BUTTON ----
            Button(
                onClick = { navController.navigate("workout") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB388FF))
            ) {
                Text("Workout Tracker", color = Color.White, fontSize = 18.sp)
            }
        }
    }
}
