package com.example.stepwise.screens

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Article
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutScreen(navController: NavController) {

    var selectedTab by rememberSaveable { mutableStateOf(0) }

    val tabs = listOf("Steps", "Custom", "Exercises", "Articles")

    val icons = listOf(
        Icons.Filled.DirectionsRun,
        Icons.Filled.FitnessCenter,
        Icons.Filled.List,
        Icons.Filled.Article
    )

    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFFFFF3E5), Color(0xFFE0BBF6))
    )

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(text = "Workout Tracker") })
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(imageVector = icons[index], contentDescription = tab) },
                        label = { Text(tab) }
                    )
                }
            }
        }
    ) { paddingValues ->

        val activity = LocalContext.current as Activity  // ⭐ Required for Step Count

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(gradient)
                .padding(paddingValues)
        ) {

            when (selectedTab) {
                0 -> StepCountScreen(activity = activity)   // ⭐ FIXED
                1 -> CustomWorkoutScreen()
                2 -> ExerciseListScreen(navController)
                3 -> ArticlesScreen()
            }
        }
    }
}
