package com.example.stepwise.googlefit

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.fitness.Fitness
import com.google.android.gms.fitness.FitnessOptions
import com.google.android.gms.fitness.data.DataType
import com.google.android.gms.fitness.request.DataReadRequest
import com.google.android.gms.fitness.request.OnDataPointListener
import com.google.android.gms.fitness.request.SensorRequest
import java.util.Calendar
import java.util.concurrent.TimeUnit

class GoogleFitManager(private val context: Context) {

    private var listener: OnDataPointListener? = null

    // ---- Fit options (steps) ----
    private val fitnessOptions: FitnessOptions =
        FitnessOptions.builder()
            .addDataType(DataType.TYPE_STEP_COUNT_DELTA, FitnessOptions.ACCESS_READ)
            .addDataType(DataType.AGGREGATE_STEP_COUNT_DELTA, FitnessOptions.ACCESS_READ)
            .build()

    fun isSignedIn(): Boolean {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return GoogleSignIn.hasPermissions(account, fitnessOptions)
    }

    fun requestPermissions(activity: Activity, requestCode: Int) {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        GoogleSignIn.requestPermissions(
            activity,
            requestCode,
            account,
            fitnessOptions
        )
    }

    // ---- Required for REAL step updates ----
    @Suppress("MissingPermission")
    fun subscribeToSteps() {
        val account = GoogleSignIn.getLastSignedInAccount(context) ?: return

        Fitness.getRecordingClient(context, account)
            .subscribe(DataType.TYPE_STEP_COUNT_DELTA)
            .addOnSuccessListener {
                Log.d("Fit", "Successfully subscribed to step updates!")
            }
            .addOnFailureListener {
                Log.e("Fit", "Failed subscribing to steps", it)
            }
    }

    // ---- Real-time step listener ----
    fun startRealTimeListener(onStep: (Int) -> Unit) {
        val account = GoogleSignIn.getLastSignedInAccount(context) ?: return

        // Remove old listener if present
        listener?.let {
            Fitness.getSensorsClient(context, account).remove(it)
        }

        listener = OnDataPointListener { dp ->
            val stepValue = dp.getValue(dp.dataType.fields[0]).asInt()
            onStep(stepValue)
        }

        Fitness.getSensorsClient(context, account)
            .add(
                SensorRequest.Builder()
                    .setDataType(DataType.TYPE_STEP_COUNT_DELTA)
                    .setSamplingRate(1, TimeUnit.SECONDS)
                    .build(),
                listener!!
            )
            .addOnSuccessListener {
                Log.d("Fit", "Real-time listener registered")
            }
            .addOnFailureListener {
                Log.e("Fit", "Real-time listener failed", it)
            }
    }

    // ---- Weekly steps (last 7 days) ----
    fun readWeeklySteps(onResult: (List<Int>) -> Unit) {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        if (account == null) {
            Log.w("Fit", "No signed-in account for weekly steps")
            onResult(emptyList())
            return
        }

        val end = Calendar.getInstance()
        val start = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -6)
        }

        val readRequest = DataReadRequest.Builder()
            .aggregate(DataType.TYPE_STEP_COUNT_DELTA)
            .bucketByTime(1, TimeUnit.DAYS)
            .setTimeRange(start.timeInMillis, end.timeInMillis, TimeUnit.MILLISECONDS)
            .build()

        Fitness.getHistoryClient(context, account)
            .readData(readRequest)
            .addOnSuccessListener { response ->
                val rawSteps = mutableListOf<Int>()

                for (bucket in response.buckets) {
                    val dataSet = bucket.dataSets.firstOrNull()
                    var daySteps = 0
                    dataSet?.dataPoints?.forEach {
                        daySteps += it.getValue(it.dataType.fields[0]).asInt()
                    }
                    rawSteps.add(daySteps)
                }

                val fixed = if (rawSteps.size < 7) {
                    rawSteps + List(7 - rawSteps.size) { 0 }
                } else {
                    rawSteps.take(7)
                }

                Log.d("Fit", "Weekly steps: $fixed")
                onResult(fixed)
            }
            .addOnFailureListener {
                Log.e("Fit", "Weekly read failed", it)
                onResult(emptyList())
            }
    }
}
