package com.example.stepwise.navigation

import android.app.Activity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.stepwise.data.UserPreferences
import com.example.stepwise.screens.*
import com.example.stepwise.screens.BMIViewModel

@Composable
fun StepWiseApp() {

    val navController = rememberNavController()
    val context = LocalContext.current

    // Shared Preferences
    val prefs = UserPreferences(context)
    val isLoggedIn by prefs.isLoggedIn.collectAsState()

    // ⭐ Create BMIViewModel manually (NO viewModel())
    val bmiViewModel = remember { BMIViewModel(context) }

    NavHost(
        navController = navController,
        startDestination = if (isLoggedIn) "home" else "login"
    ) {

        composable("login") {
            LoginScreen(navController = navController, prefs = prefs)
        }

        composable("home") {
            HomeScreen(navController = navController)
        }

        composable("bmi") {
            BMICalculatorScreen(viewModel = bmiViewModel)
        }

        composable("workout") {
            WorkoutScreen(navController = navController)
        }

        composable("steps") {
            val activity = LocalContext.current as Activity
            StepCountScreen(activity = activity)
        }

        composable("customWorkout") {
            CustomWorkoutScreen()
        }

        composable("exercises") {
            ExerciseListScreen(navController = navController)
        }

        composable("exerciseDetail/{categoryName}") { backStackEntry ->
            val name = backStackEntry.arguments?.getString("categoryName") ?: "Unknown"
            ExerciseDetailScreen(category = name)
        }

        composable("articles") {
            ArticlesScreen()
        }
    }
}
